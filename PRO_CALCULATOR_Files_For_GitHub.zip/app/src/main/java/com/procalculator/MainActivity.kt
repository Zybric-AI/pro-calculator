package com.procalculator

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

private data class CalcState(val expression: String, val result: String)
private data class Palette(val bg: Color, val panel: Color, val key: Color, val accent: Color, val text: Color)

private val palettes = listOf(
    Palette(Color(0xFF101522), Color(0xFF1B2638), Color(0xFF29364C), Color(0xFF48B7FF), Color.White),
    Palette(Color(0xFFF2F4F8), Color.White, Color(0xFFE4E9F1), Color(0xFF2864D8), Color(0xFF172033)),
    Palette(Color(0xFF171021), Color(0xFF281A38), Color(0xFF3A2850), Color(0xFFC084FC), Color.White),
    Palette(Color(0xFF071C19), Color(0xFF10332D), Color(0xFF1B4940), Color(0xFF34D399), Color.White),
    Palette(Color(0xFF1B1111), Color(0xFF332020), Color(0xFF4B2D2D), Color(0xFFFF9B62), Color.White)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ProCalculator() }
    }
}

@Composable
private fun ProCalculator() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pro_calc", 0) }
    var expression by remember { mutableStateOf(prefs.getString("expr", "") ?: "") }
    var result by remember { mutableStateOf(prefs.getString("result", "0") ?: "0") }
    var degree by remember { mutableStateOf(prefs.getBoolean("degree", true)) }
    var sound by remember { mutableStateOf(prefs.getBoolean("sound", true)) }
    var paletteIndex by remember { mutableIntStateOf(prefs.getInt("palette", 0).coerceIn(palettes.indices)) }
    var showAdvanced by remember { mutableStateOf(true) }
    var showSettings by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var editKeys by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val palette = palettes[paletteIndex]
    val tone = remember { ToneGenerator(AudioManager.STREAM_SYSTEM, 55) }
    val undo = remember { mutableStateListOf<CalcState>() }
    val redo = remember { mutableStateListOf<CalcState>() }
    val history = remember {
        mutableStateListOf<String>().apply {
            val raw = prefs.getString("history", "[]") ?: "[]"
            try { val a = JSONArray(raw); for (i in 0 until a.length()) add(a.getString(i)) } catch (_: Exception) {}
        }
    }
    val defaultKeys = listOf("7","8","9","÷","4","5","6","×","1","2","3","−","0",".","=","+")
    val keys = remember { mutableStateListOf<String>().apply {
        val raw = prefs.getString("keys", "") ?: ""
        if (raw.isNotBlank()) try { val a=JSONArray(raw); for(i in 0 until a.length()) add(a.getString(i)) } catch (_:Exception) {}
        if (size != 16) { clear(); addAll(defaultKeys) }
    } }

    fun save() {
        prefs.edit().putString("expr", expression).putString("result", result)
            .putBoolean("degree", degree).putBoolean("sound", sound).putInt("palette", paletteIndex)
            .putString("keys", JSONArray(keys).toString())
            .putString("history", JSONArray(history.take(100)).toString()).apply()
    }
    fun snapshot() { undo.add(CalcState(expression, result)); if (undo.size > 100) undo.removeAt(0); redo.clear() }
    fun tap() { if (sound) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 35) }
    fun append(s: String) {
        snapshot()
        expression += s
        error = ""
        save()
    }
    fun evaluate() {
        if (expression.isBlank()) return
        try {
            val value = ExpressionParser(expression, degree).parse()
            if (!value.isFinite()) throw IllegalArgumentException("Результат не определён")
            snapshot()
            result = formatNumber(value)
            history.add(0, "$expression = $result")
            if (history.size > 100) history.removeAt(history.lastIndex)
            expression = result
            error = ""
            save()
        } catch (e: Exception) { error = e.message ?: "Проверь выражение" }
    }
    fun press(k: String) {
        tap()
        when (k) {
            "AC" -> { snapshot(); expression=""; result="0"; error=""; save() }
            "⌫" -> { snapshot(); if (expression.isNotEmpty()) expression=expression.dropLast(1); error=""; save() }
            "=" -> evaluate()
            "↶" -> if (undo.isNotEmpty()) { redo.add(CalcState(expression,result)); val s=undo.removeAt(undo.lastIndex); expression=s.expression; result=s.result; error=""; save() }
            "↷" -> if (redo.isNotEmpty()) { undo.add(CalcState(expression,result)); val s=redo.removeAt(redo.lastIndex); expression=s.expression; result=s.result; error=""; save() }
            "⇧" -> showAdvanced = !showAdvanced
            "DEG/RAD" -> { degree=!degree; save() }
            "()" -> append(if (expression.count { it=='(' } > expression.count { it==')' }) ")" else "(")
            "√" -> append("sqrt(")
            "x²" -> append("^2")
            "xʸ" -> append("^")
            "π" -> append("pi")
            "e" -> append("e")
            "sin","cos","tan","asin","acos","atan","ln","log","abs" -> append("$k(")
            "!" -> append("!")
            "±" -> { snapshot(); expression = if (expression.isBlank()) "-" else if (expression.startsWith("-")) expression.drop(1) else "-($expression)"; save() }
            else -> append(when(k) { "÷"->"/"; "×"->"*"; "−"->"-"; "−"->"-"; else->k })
        }
    }

    MaterialTheme(colorScheme = if (paletteIndex == 1) lightColorScheme() else darkColorScheme()) {
        Column(Modifier.fillMaxSize().background(palette.bg).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Column {
                    Text("PRO CALCULATOR", color=palette.text, fontSize=19.sp, fontWeight=FontWeight.Bold)
                    Text("НАУЧНЫЙ КАЛЬКУЛЯТОР", color=palette.accent, fontSize=10.sp, letterSpacing=2.sp)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    SmallAction("⚙", palette) { showSettings=true }
                    SmallAction("▤", palette) { showHistory=true }
                }
            }
            Column(Modifier.fillMaxWidth().weight(1f).background(palette.panel, RoundedCornerShape(22.dp)).padding(18.dp), verticalArrangement=Arrangement.Bottom, horizontalAlignment=Alignment.End) {
                Text(expression.ifBlank { "0" }, color=palette.text.copy(alpha=.72f), fontSize=23.sp, textAlign=TextAlign.End, modifier=Modifier.fillMaxWidth())
                if (error.isNotBlank()) Text(error, color=Color(0xFFFF7777), fontSize=13.sp)
                Spacer(Modifier.height(10.dp))
                Text(result, color=palette.text, fontSize=38.sp, fontWeight=FontWeight.SemiBold, textAlign=TextAlign.End, modifier=Modifier.fillMaxWidth())
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                listOf("↶","↷","⌫","AC","DEG/RAD","⇧").forEach { k ->
                    Box(Modifier.weight(1f).height(43.dp).background(palette.key, RoundedCornerShape(12.dp)).clickable { press(k) }, contentAlignment=Alignment.Center) {
                        Text(if(k=="DEG/RAD") if(degree) "DEG" else "RAD" else k, color=palette.accent, fontWeight=FontWeight.Bold, fontSize=if(k=="DEG/RAD") 11.sp else 17.sp)
                    }
                }
            }
            if (showAdvanced) {
                val adv = listOf("sin","cos","tan","(",")","√","x²","xʸ","asin","acos","atan","!","ln","log","abs","π","e","%")
                Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    adv.chunked(6).forEach { row ->
                        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                            row.forEach { k -> CalcKey(k, palette, Modifier.weight(1f).height(42.dp), true) { press(if(k=="(" || k==")") k else k) } }
                            repeat(6-row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            if (editKeys) Text("Режим перестановки: нажми две кнопки по очереди", color=palette.accent, fontSize=12.sp)
            LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp), modifier=Modifier.heightIn(max=220.dp)) {
                items(keys.chunked(4)) { row ->
                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        row.forEach { k -> CalcKey(k, palette, Modifier.weight(1f).height(54.dp), false) {
                            if (editKeys) {
                                // In edit mode, tap a key then another key to swap them.
                                val first = prefs.getString("swap_first", null)
                                if (first == null) prefs.edit().putString("swap_first", k).apply()
                                else {
                                    val a=keys.indexOf(first); val b=keys.indexOf(k)
                                    if(a>=0 && b>=0) { val temp=keys[a]; keys[a]=keys[b]; keys[b]=temp; save() }
                                    prefs.edit().remove("swap_first").apply()
                                }
                            } else press(k)
                        } }
                        repeat(4-row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                OutlinedButton(onClick={ editKeys=!editKeys; prefs.edit().remove("swap_first").apply() }, modifier=Modifier.weight(1f)) { Text(if(editKeys) "Готово" else "↔ Кнопки") }
                OutlinedButton(onClick={ showAdvanced=!showAdvanced }, modifier=Modifier.weight(1f)) { Text(if(showAdvanced) "Скрыть научные" else "Научные") }
            }
        }

        if (showSettings) AlertDialog(
            onDismissRequest={showSettings=false},
            title={Text("Настройки PRO CALCULATOR")},
            text={
                Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text("Тема оформления")
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        listOf("Ночь","Светлая","Фиолетовая","Зелёная","Тёплая").forEachIndexed { i,n ->
                            FilterChip(selected=paletteIndex==i,onClick={paletteIndex=i;save()},label={Text(n,fontSize=10.sp)})
                        }
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("Звук нажатий",Modifier.weight(1f)); Switch(checked=sound,onCheckedChange={sound=it;save()}) }
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("Углы в градусах",Modifier.weight(1f)); Switch(checked=degree,onCheckedChange={degree=it;save()}) }
                    Text("Кнопки можно менять местами через режим «↔ Кнопки».", fontSize=12.sp)
                }
            },
            confirmButton={TextButton(onClick={ showSettings=false }) { Text("Закрыть") }}
        )
        if (showHistory) AlertDialog(
            onDismissRequest={showHistory=false},
            title={Text("История вычислений")},
            text={
                Column {
                    if(history.isEmpty()) Text("Пока вычислений нет")
                    else LazyColumn(Modifier.heightIn(max=350.dp)) {
                        items(history) { item -> Text(item,Modifier.fillMaxWidth().clickable {
                            val left=item.substringBefore(" = "); expression=left; error=""; showHistory=false; save()
                        }.padding(vertical=8.dp)) }
                    }
                }
            },
            confirmButton={TextButton(onClick={ showHistory=false }) { Text("Закрыть") }},
            dismissButton={TextButton(onClick={history.clear();save()}) { Text("Очистить") }}
        )
    }
}

@Composable
private fun SmallAction(label:String, p:Palette, onClick:()->Unit) {
    Box(Modifier.size(42.dp).background(p.key,RoundedCornerShape(13.dp)).clickable(onClick=onClick),contentAlignment=Alignment.Center) {
        Text(label,color=p.accent,fontSize=20.sp,fontWeight=FontWeight.Bold)
    }
}
@Composable
private fun CalcKey(label:String,p:Palette,modifier:Modifier,scientific:Boolean,onClick:()->Unit) {
    val op = label in listOf("+","−","×","÷","=")
    Box(modifier.background(if(op) p.accent.copy(alpha=.22f) else p.key,RoundedCornerShape(14.dp)).clickable(onClick=onClick),contentAlignment=Alignment.Center) {
        Text(label,color=if(op) p.accent else p.text,fontSize=if(scientific) 14.sp else 21.sp,fontWeight=FontWeight.Medium)
    }
}

private fun formatNumber(v:Double):String {
    if (abs(v) < 1e-12) return "0"
    if (v.isFinite() && v == v.toLong().toDouble() && abs(v) < 1e15) return v.toLong().toString()
    return "%.10g".format(java.util.Locale.US, v)
}

/** Recursive-descent expression parser: + - * / ^, parentheses, %, factorial and functions. */
private class ExpressionParser(private val source:String, private val degrees:Boolean) {
    private var pos=0
    fun parse():Double { val v=expression(); skip(); if(pos<source.length) fail("Лишний символ: ${source[pos]}"); return v }
    private fun skip(){ while(pos<source.length && source[pos].isWhitespace()) pos++ }
    private fun eat(c:Char):Boolean { skip(); if(pos<source.length && source[pos]==c){pos++;return true};return false }
    private fun fail(s:String):Nothing=throw IllegalArgumentException(s)
    private fun expression():Double { var x=term(); while(true){ when { eat('+')->x+=term(); eat('-')->x-=term(); else->return x } } }
    private fun term():Double { var x=power(); while(true){ when { eat('*')->x*=power(); eat('/')->{val d=power();if(d==0.0)fail("На ноль делить нельзя");x/=d}; else->return x } } }
    private fun power():Double { var x=unary(); if(eat('^')) x=x.pow(power()); return x }
    private fun unary():Double { if(eat('+'))return unary(); if(eat('-'))return -unary(); return postfix() }
    private fun postfix():Double { var x=atom(); while(true){ when { eat('%')->x/=100.0; eat('!')->{if(x<0 || x>170 || x%1.0!=0.0)fail("Факториал доступен для целых 0–170"); var f=1.0; for(i in 2..x.toInt())f*=i; x=f}; else->return x } } }
    private fun atom():Double {
        skip()
        if(eat('(')){ val x=expression(); if(!eat(')'))fail("Не закрыта скобка"); return x }
        if(pos>=source.length) fail("Ожидалось число")
        if(source[pos].isDigit() || source[pos]=='.') {
            val start=pos
            while(pos<source.length && (source[pos].isDigit() || source[pos]=='.'))pos++
            return source.substring(start,pos).toDoubleOrNull() ?: fail("Неверное число")
        }
        if(source[pos].isLetter()) {
            val start=pos; while(pos<source.length && source[pos].isLetter())pos++
            val name=source.substring(start,pos).lowercase()
            if(name=="pi")return Math.PI
            if(name=="e")return Math.E
            if(!eat('(')) fail("После $name нужна скобка")
            val a=expression(); if(!eat(')'))fail("Не закрыта скобка")
            val angle=if(degrees) Math.toRadians(a) else a
            return when(name) {
                "sqrt" -> if(a<0) fail("Корень из отрицательного числа") else sqrt(a)
                "sin" -> sin(angle); "cos" -> cos(angle); "tan" -> tan(angle)
                "asin" -> { val v=asin(a); if(degrees)Math.toDegrees(v) else v }
                "acos" -> { val v=acos(a); if(degrees)Math.toDegrees(v) else v }
                "atan" -> { val v=atan(a); if(degrees)Math.toDegrees(v) else v }
                "ln" -> ln(a); "log" -> log10(a); "abs" -> abs(a)
                else -> fail("Неизвестная функция: $name")
            }
        }
        fail("Неожиданный символ: ${source[pos]}")
    }
}
