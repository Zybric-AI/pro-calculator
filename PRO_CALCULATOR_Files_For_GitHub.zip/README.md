# PRO CALCULATOR — Android project

Это исходный Android-проект (Kotlin + Jetpack Compose), а не готовый APK.

## Сборка APK
1. Установите Android Studio на компьютер.
2. Откройте папку `ProCalculatorAndroid` в Android Studio.
3. Дождитесь синхронизации Gradle и установки Android SDK 35.
4. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Функции
- Обычные операции, скобки, степени, квадратный корень, проценты.
- sin/cos/tan и обратные функции, ln/log, abs, факториал, π и e.
- Переключение DEG/RAD.
- 5 тем, звук нажатий, история с сохранением.
- Undo/Redo.
- Перестановка основных клавиш: включите «↔ Кнопки» и выберите две кнопки по очереди.

Для первой сборки требуется интернет, чтобы Gradle скачал зависимости и Android Gradle Plugin.
